package com.jdbcTemplate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	public static void main(String[] args) {
		ApplicationContext c=new ClassPathXmlApplicationContext("spring.xml");		
		TableDao Tdao=(TableDao) c.getBean("tdao");
		//save method with 3 arguments name age phone it will save the 3 args in to JDbcTemplate database.
		//System.out.println(Tdao.save("padhu",989,98745));
		//Tdao.updatePhone("padhu", 91772345);
		//Tdao.deleteName("padhu", 91772345);
		
	}

}
