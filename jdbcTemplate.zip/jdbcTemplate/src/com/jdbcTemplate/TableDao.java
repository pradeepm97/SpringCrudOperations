package com.jdbcTemplate;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class TableDao {
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	//operations starts... now
	//save method
	public int save(String name,int age,int phone) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Table t=(Table)context.getBean("table");
		t.setName(name);
		t.setAge(age);
		t.setPhone(phone);
		String sql="insert into recapknolwdge.jdbctemplate values(?,?,?)";
		System.out.println("Data saved...");
		return jdbcTemplate.update(sql,t.getName(),t.getAge(),t.getPhone());
		
	}
	public int updatePhone(String name,int phone) {
		String sql="update recapknolwdge.jdbctemplate set phone=? where name=?";
		System.out.println(jdbcTemplate.update(sql,phone,name)+" :Rows are updated..");
		
		return 1;
	}
	public int deleteName(String name,int phone) {
		String sql="delete from recapknolwdge.jdbctemplate where phone=? and name=?";
		System.out.println(jdbcTemplate.update(sql,phone,name)+" :Rows are deleted..");
		
		return 1;
	}
	public void count() {
		
	}
	// select query for select query we need to use other jdbctemplate method because it having result sets....
	//
	
	

}
